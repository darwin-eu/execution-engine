# Test DatabaseConnector

This test study demonstrates an example of connecting to a CDM database using 
DatabaseConnector.
