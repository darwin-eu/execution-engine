# Test CDMConnector

This test study demonstrates an example of connecting to a CDM database using 
DBI and querying a CDM with CDMConnector and dplyr.

